var youtubeVideos = [
    {
        link : `<iframe width="560" height="315" src="https://www.youtube.com/embed/eJneYGxqnR0" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>`,
        name : "[Piano&Violin Cover] Salut d'amour",
        content: `Happy Valentine's day
Wish you had sweet day !
Today I send you a very lovely  piece ^o^`,
    },
    {
        link : `<iframe width="560" height="315" src="https://www.youtube.com/embed/BwsMALgA1V8" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>`,
        name : "[ Piano Cover ] Speechless",
        content: ``,
    },
];