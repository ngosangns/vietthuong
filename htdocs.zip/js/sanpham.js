var sanpham = [
    {
        name : "Piano",
        image : "piano.jpg",
        link : "./search.php?search=Piano",
    },
    {
        name : "Guitar",
        image : "guitar.jpg",
        link : "./search.php?search=Guitar",
    },
    {
        name : "Ukulele",
        image : "ukulele.jpg",
        link : "./search.php?search=Ukulele",
    },
    {
        name : "Violin",
        image : "violin.jpg",
        link : "./search.php?search=Violin",
    },
    {
        name : "Organ",
        image : "organ.jpg",
        link : "./search.php?search=Organ",
    },

]